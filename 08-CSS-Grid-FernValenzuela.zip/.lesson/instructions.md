# Instructions  

---

Write some code in 'style.css' to make your page look like this:
![Screenshot](./assets/Screenshot.png)

That gap in between the rows and columns is `10px` wide.