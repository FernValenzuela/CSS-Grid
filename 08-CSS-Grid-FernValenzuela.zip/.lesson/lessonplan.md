# Lesson plan
  
---

```
.myGrid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-template-rows: auto;
  gap: 10px;
}

.myGrid div {
  height: 50px;
  border: solid black 1px;
  background-color: lightgray;
}

```